﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ОООПосуда_Кадильникова
{
    /// <summary>
    /// Логика взаимодействия для Главная_админ.xaml
    /// </summary>
    public partial class Главная_админ : Window
    {
        public Главная_админ()
        {
            InitializeComponent();
        }

        private void Page1_Click(object sender, RoutedEventArgs e)
        {
            Каталог_для_админа Каталог_для_админа = new Каталог_для_админа();
            Каталог_для_админа.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow MainWindow = new MainWindow();
            MainWindow.Show();
            this.Close();
        }

        private void Page2_Click(object sender, RoutedEventArgs e)
        {
            Добавление Добавление = new Добавление();
            Добавление.Show(); 
            this.Close();
        }

        private void Page4_Click(object sender, RoutedEventArgs e)
        {
            лкадмин лкадмин = new лкадмин();
            лкадмин.Show();
            this.Close();
        }
    }
}
