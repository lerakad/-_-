﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ОООПосуда_Кадильникова
{
    /// <summary>
    /// Логика взаимодействия для Главная.xaml
    /// </summary>
    public partial class Главная : Window
    {
        public Главная()
        {
            InitializeComponent();
        }

        private void Page1_Click(object sender, RoutedEventArgs e)
        {
            Каталог Каталог = new Каталог();
            Каталог.Show();
            this.Close();
        }

        private void Page3_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Page4_Click(object sender, RoutedEventArgs e)
        {
            Оформление_заказа Оформление_заказа = new Оформление_заказа();
            Оформление_заказа.Show();
            this.Close();
        }

        private void Page5_Click(object sender, RoutedEventArgs e)
        {
            личныйкабинет личныйкабинет = new личныйкабинет();
            личныйкабинет.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow MainWindow = new MainWindow();
            MainWindow.Show();
            this.Close();
        }
    }
}
