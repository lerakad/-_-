﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ОООПосуда_Кадильникова
{
    /// <summary>
    /// Логика взаимодействия для личныйкабинет.xaml
    /// </summary>
    public partial class личныйкабинет : Window
    {
        public личныйкабинет()
        {
            InitializeComponent();
        }

        private void Page1_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Операция успешно выполнена!");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Главная Главная = new Главная();
            Главная.Show();
            this.Close();
        }
    }
}
