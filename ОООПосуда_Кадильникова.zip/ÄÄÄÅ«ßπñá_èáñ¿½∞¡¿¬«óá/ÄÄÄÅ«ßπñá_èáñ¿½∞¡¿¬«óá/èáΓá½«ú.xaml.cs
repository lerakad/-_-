﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ОООПосуда_Кадильникова
{
    /// <summary>
    /// Логика взаимодействия для Каталог.xaml
    /// </summary>
    public partial class Каталог : Window
    {
        public Каталог()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Главная Главная = new Главная();
            Главная.Show();
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Оформ_заказа3 Оформ_заказа3 = new Оформ_заказа3();
            Оформ_заказа3.Show();
            this.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Оформ_заказа2 Оформ_заказа2 = new Оформ_заказа2 ();
            Оформ_заказа2.Show();
            this.Close();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Оформление_заказа Оформление_заказа = new Оформление_заказа();
            Оформление_заказа.Show();
            this.Close();
        }
    }
}
